import React, { useEffect } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { store } from './app/store';
import { login } from './features/auth/authSlice';
import Navbar from './components/Navbar';
import UserList from './components/UserList';

const AuthLoader = ({ children }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    const token = localStorage.getItem('authToken');
    const user = localStorage.getItem('authUser');
    if (token && user) {
      dispatch(login({ token, user: JSON.parse(user) }));
    }
  }, [dispatch]);

  return <>{children}</>;
};

const AppContent = () => {
  const { isAuthenticated, user } = useSelector((state) => state.auth);

  return (
    <div className="p-4">
      <Navbar />
      <h1 className="text-xl font-bold">Users</h1>
      {isAuthenticated ? (
        <>
          <p className="text-green-600 mb-2">Welcome, {user?.name}</p>
          <UserList />
        </>
      ) : (
        <p className="text-red-500">Not Logged In</p>
      )}
    </div>
  );
};

const App = () => {
  return (
    <Provider store={store}>
      <AuthLoader>
        <AppContent />
      </AuthLoader>
    </Provider>
  );
};

export default App;
