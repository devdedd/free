import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { login, logout } from '../features/auth/authSlice';

const AuthButtons = () => {
  const dispatch = useDispatch();
  const { user, isAuthenticated } = useSelector((state) => state.auth);

  const handleLogin = () => {
    const token = 'abc123'; // Replace with real token from API if available
    const userInfo = { name: 'Deepak', email: 'deepak@example.com' };

    // 🔐 Save token to localStorage
    localStorage.setItem('authToken', token);
    localStorage.setItem('authUser', JSON.stringify(userInfo));

    dispatch(login({ user: userInfo, token }));
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('authUser');
    dispatch(logout());
  };

  return (
    <div>
      <h3>{isAuthenticated ? `Welcome, ${user.name}` : 'Not Logged In'}</h3>
      <button onClick={handleLogin} className="bg-green-500 px-2 py-1 text-white m-1">Login</button>
      <button onClick={handleLogout} className="bg-red-500 px-2 py-1 text-white m-1">Logout</button>
    </div>
  );
};

export default AuthButtons;
