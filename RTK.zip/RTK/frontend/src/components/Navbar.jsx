// src/components/Navbar.jsx
import React from 'react';
import AuthButtons from './AuthButtons';

const Navbar = () => {
  return (
    <nav className="bg-blue-600 p-4 text-white flex justify-between">
      <span>My App</span>
      <AuthButtons />
    </nav>
  );
};

export default Navbar;
