import { configureStore } from '@reduxjs/toolkit';
import { userApi } from '../features/api/userApi';
import authReducer from '../features/auth/authSlice'; // if you have one

export const store = configureStore({
  reducer: {
    [userApi.reducerPath]: userApi.reducer,
    auth: authReducer, // ✅ make sure this exists if you're using getState().auth.token
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(userApi.middleware),
});
